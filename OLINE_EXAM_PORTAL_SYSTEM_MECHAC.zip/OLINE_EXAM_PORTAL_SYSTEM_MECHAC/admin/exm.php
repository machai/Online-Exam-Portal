
<?php


//session_start();

require_once("models/database.php");
require_once("models/adminModel.php");
require_once("models/studentsModel.php");
require_once("models/admissionModel.php");
require_once("models/modulesModel.php");
require_once("models/examsModel.php");
require_once("models/reportsModel.php");

$lecture = new Lecture();
$student = new Student();
$admission = new Admission();
$exam = new Exams();
$module = new Modules();
$reports = new Reports();

$action = null;

if(isset($_REQUEST['action'])) {

    if($_SERVER['REQUEST_METHOD'] == 'GET') {
        $action = filter_input(INPUT_GET, "action");
    }
    else {
        //get the request
        $action = filter_input(INPUT_POST, "action");
    }


    if($action == "addexam") {
        include("views/addexam.php");
    }

    //
    if($action == "exam-add") {
        $randomTransactionID = rand(1000, 9999).'-'.rand(1000, 9999).'-'.rand(1000, 9999);
        $data = array(
            'TransactionID' => $randomTransactionID,
            'ModCode' => $_REQUEST['ModCode'],
            'StartTime' => $_REQUEST['StartTime'],
            'UploadTime' => $_REQUEST['UploadTime'],
            'DateExam' => $_REQUEST['DateExam'],
            'AnswerPaperPDF' => $_FILES['document_file']['name']
        );
        
        if(in_array('', $data)) {
            echo "<script>alert('Please type all required data.')</script>";
            include("views/addexam.php");
            exit();
        }

        $dir_path = "../exams";
        $student_dir = "../submissions";

        if(!is_dir($dir_path)) {
            mkdir($dir_path);
            mkdir($student_dir);
        }

        $filename = $_FILES['document_file']['name']; //collect the document file name

        $file_parts = explode('.', $filename); //separate document info in parts

        $file_ext = end($file_parts);

        //rewrite the document file name
        $filename = strtoupper($data['ModCode'])."_".$data['DateExam']."_Exam.".$file_ext;

        $targetPath = $dir_path."/".$filename;

        //Function to insert from data into database
        if($exam->insertExam($data, $filename)) {
            //uploads file to a folder
            if(move_uploaded_file($_FILES['document_file']['tmp_name'], $targetPath)) {
                echo "<script>alert('New examination has been added.')</script>";
                echo "<script>alert('Document '".$filename."' has been uploaded.'')</script>";
            }
            else {
                echo "<script>alert('Sorry failed to upload document.')</script>";
            }
        }
        //redirects back after saving
        echo "<script>window.open('?action=addexam','_self')</script>";
        include("views/dash7.php?action=addexam"); 
        exit();
    }

}

exit();


   




?>












































<?php //require_once("sup-model.php"); 
 // <div id="wrapper" style="width:60% ">
 //     <!--  <img src="products.png" alt="Image" height="150" width="300"> <img src="suplement.png" alt="Image" height="150" width="300">
	
 // <div ><b><font color="blue">Select Module for exam here:&nbsp&nbsp</font><?php //echo $inv_num ?><!--  </b></div><br> -->
		<!-- <form class = "form3" action="dash7.php" method="get"> -->
       
          <!--  <select class="option" style="width:265px; height:30px;"name="ModCode" id = "splid"> 
		          <?php //foreach( $supplement as $supp) : ?>
                 <option><?php //echo $supp[0] ?></option>
		          <?php //endforeach; ?>
           </select><br><br>
            -->
          <!--  <input class="btn btn-success" type="submit"  name="submit"  value="Search" id="createApp"><br>
	      </form>
		
		
       </fieldset>
        <form class = "form3" id="formBuy" action="sup-model.php" method="get">
         <br>  -->
     
		  <!--  <font color="black">Module code:</font><br>
	  
		   <input type="text" style="width:265px; height:30px;" name="sup_ID" readonly  
             value="<?php// foreach( $suplDetail as $sup) : ?><?php// echo $sup[0]?><?php// endforeach; ?>" /><br/><br/>
			 
            <font color="black">Module description:</font></label><br>
			<input type="text" style="width:265px; height:30px;" name="description" readonly  
             value="<?php //foreach( $suplDetail as $sup) : ?><?php //echo $sup[1]?><?php// endforeach; ?>"/><br/><br>
			 
            <font color="black">Create date: </font></label><br>
            <input type="date" id="texttwo" style="width:265px; height:30px;" name="date"  Required><br><br>


            <font color="black">Enter starting times:(00:00:00) </font></label><br>
            <input type="text" id="texttwo" style="width:265px; height:30px;" name="qty"  Required><br><br -->>
 -->
            
           <!--  <input class="btn btn-success" type="submit" name="submit"  value="add" id="add">
			<input class="btn btn-danger" type="submit"  name="submit"  value="Cancel" id="cancel">
 -->
 -->


<!-- </div>
</div>
</form> -->