<?php

interface userAuthorisation {
    public function login($email, $password);
    public function logout();
    public function is_user_auth();
}

abstract class DBConnect {

    private $host = 'localhost';
    private $db_name = 'my_online_exam_portal';
    private $username = 'root';
    private $password = '';
    private $conn = null;

    public function connect() {
        try {
            $this->conn= new PDO('mysql:host='.$this->host.';dbname='.$this->db_name, $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }
        catch (PDOException $ex) {
            $msg = $ex->getMessage();
            echo 'Connection Error : '.$msg;
            include('views/404.php');
        }
        return $this->conn;
    }

}

?>