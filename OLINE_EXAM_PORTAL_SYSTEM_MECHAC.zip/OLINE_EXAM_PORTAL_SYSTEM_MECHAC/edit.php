<?php
require_once("dbcontroller.php");
$db_handle = new DBController();
if(!empty($_POST["submit"])) {
    $query = "UPDATE students set Student_Name = '".$_POST["Student_Name"]."', Student_Surname = '".$_POST["Student_Surname"]."', Email_Address = '".$_POST["Email_Address"]."' WHERE  Student_Number =".$_GET["id"];
    $result = $db_handle->executeQuery($query);
	if(!$result){
		$message = "Problem in Editing! Please Retry!";
	} else {
		header("Location:student_data.php");
	}

}
$result = $db_handle->runQuery("SELECT * FROM students WHERE Student_Number='" . $_GET["id"] . "'");
?>
<link href="style.css" type="text/css" rel="stylesheet" />
<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
<script>
function validate() {
	var valid = true;	
	$(".demoInputBox").css('background-color','');
	$(".info").html('');
	
	if(!$("#Student_Name").val()) {
		$("#Student_Name-info").html("(required)");
		$("#Student_Name").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#Student_Surname").val()) {
		$("#Student_Surname-info").html("(required)");
		$("#Student_Surname").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#Email_Address").val()) {
		$("#Email_Address-info").html("(required)");
		$("#Email_Address").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#price").val()) {
		$("#price-info").html("(required)");
		$("#price").css('background-color','#FFFFDF');
		valid = false;
	}	
	if(!$("#stock_count").val()) {
		$("#stock_count-info").html("(required)");
		$("#stock_count").css('background-color','#FFFFDF');
		valid = false;
	}	
	return valid;
}
</script>
<form name="frmToy" method="post" action="" id="frmToy" onClick="return validate();">
<div id="mail-status"></div>


<div>
<label style="padding-top:20px;">Student Name</label>
<span id="Student_Name-info" class="info"></span><br/>
<input type="text" name="Student_Name" id="Student_Name" class="demoInputBox" value="<?php echo $result[0]["Student_Name"]; ?>">
</div>
<div>
<label>Student Surname</label>
<span id="Student_Surname-info" class="info"></span><br/>
<input type="text" name="Student_Surname" id="Student_Surname" class="demoInputBox" value="<?php echo $result[0]["Student_Surname"]; ?>">
</div>

<div>
<label>Student Number</label>
<span id="Student_Surname-info" class="info"></span><br/>
<input type="text" name="Student_Surname" id="Student_Surname" class="demoInputBox" value="<?php echo $result[0]["Student_Number"]; ?>">
</div>

<div>
<label>Email Address</label> 
<span id="Email_Address-info" class="info"></span><br/>
<input type="text" name="Email_Address" id="Email_Address" class="demoInputBox" value="<?php echo $result[0]["Email_Address"]; ?>">
</div>
<div>
<input type="submit" name="submit" id="btnAddAction" value="Save" />
</div>
</div>
