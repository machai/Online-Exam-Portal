
<?php
  require_once("perpage.php");  
  require_once("dbcontroller.php");
  $db_handle = new DBController();
  
  $name = "";
  $code = "";
  
  $queryCondition = "";
  if(!empty($_POST["search"])) {
    foreach($_POST["search"] as $k=>$v){
      if(!empty($v)) {

        $queryCases = array("StudentNumber","ModCode");
        if(in_array($k,$queryCases)) {
          if(!empty($queryCondition)) {
            $queryCondition .= " AND ";
          } else {
            $queryCondition .= " WHERE ";
          }
        }
        switch($k) {
          case "StudentNumber":
            $name = $v;
            $queryCondition .= "ModCode LIKE '" . $v . "%'";
            break;
          case "ModCode":
            $code = $v;
            $queryCondition .= "ModCode LIKE '" . $v . "%'";
            break;
        }
      }
    }
  }
  //  get student table from database
  $orderby = " ORDER BY ModCode desc"; 
  $sql = "SELECT * FROM exam_output " . $queryCondition;
  $href = 'dash6.php';          
    
  $perPage = 5; 
  $page = 1;
  if(isset($_POST['page'])){
    $page = $_POST['page'];
  }
  $start = ($page-1)*$perPage;
  if($start < 0) $start = 0;
    
  $query =  $sql . $orderby .  " limit " . $start . "," . $perPage; 
  $result = $db_handle->runQuery($query);
  
  if(!empty($result)) {
    $result["perpage"] = showperpage($sql, $perPage, $href);
  }
?>

<style>
    
table,th, td {
  border: 1px solid #D3F5B8;
  background-color: #96D4D4;
  /*border-collapse: collapse;
   width: 80%;*/
}
th, td {
  background-color: #96D4D4;
}
#toys-grid {
    margin-bottom: 30px;
}

#toys-grid .txt-heading {
    background-color: #D3F5B8;
}

#toys-grid table {
    width: 100%;
    background-color: #F0F0F0;
}

#toys-grid table td {
    background-color: #FFEFD5;
}


.search-box {
    border: 1px solid #F0F0F0;
    background-color: #C8EEFD;
    margin: 2px 0px;
}

.demoInputBox {
    padding: 10px;
    border: #F0F0F0 1px solid;
    border-radius: 4px;
    margin: 0px 5px
}

.btnSearch {
    padding: 10px;
    border: #F0F0F0 1px solid;
    border-radius: 4px;
    margin: 0px 5px;
}

.perpage-link {
    padding: 5px 10px;
    border: #C8EEFD 2px solid;
    border-radius: 4px;
    margin: 0px 5px;
    background: #FFF;
    cursor: pointer;
}

.current-page {
    padding: 5px 10px;
    border: #C8EEFD 2px solid;
    border-radius: 4px;
    margin: 0px 5px;
    background: #C8EEFD;
}

.btnEditAction {
    background-color: #2FC332;
    padding: 2px 5px;
    color: #FFF;
    text-decoration: none;
}

.btnDeleteAction {
    background-color: #D60202;
    padding: 2px 5px;
    color: #FFF;
    text-decoration: none;
}

#btnAddAction {
    background-color: #09F;
    border: 0;
    padding: 5px 10px;
    color: #FFF;
    text-decoration: none;
}

    }
  </style>

  
    <h2>Exam Management</h2>
    <div style="text-align:right;margin:20px 0px 10px;">
    <a id="btnAddAction" href="add_exam.php">Add New Exam</a>
    </div>
    <div id="toys-grid">      
      <form name="frmSearch" method="post" action="dash6.php">
      <div class="search-box">
      <p><input type="text" placeholder="Module Name" name="search[StudentNumber]" class="demoInputBox" value="<?php echo $name; ?>"  /><input type="text" placeholder="Module code" name="search[ModCode]" class="demoInputBox" value="<?php echo $code; ?>" /><input type="submit" name="go" class="btnSearch" value="Search"><input type="reset" class="btnSearch" value="Reset" onclick="window.location='dash6.php'"></p>
      </div>
      
      <table cellpadding="10" cellspacing="1">
        <thead>
          <tr>
          <th><strong>Module code</strong></th>  
          <th><strong>Student number</strong></th>   
          <th><strong>Exam Date</strong></th>
          <th><strong>Start Time</strong></th>
           <th><strong>Completion Time</strong></th>
      
       <!--    <th><strong>Action</strong></th> -->
          
          </tr>
        </thead>
        <tbody>
          <?php
          if(!empty($result)) {
            foreach($result as $k=>$v) {
              if(is_numeric($k)) {
          ?>
          <tr>
          <td><?php echo $result[$k]["ModCode"]; ?></td>
          <td><?php echo $result[$k]["StudentNumber"]; ?></td>
          <td><?php echo $result[$k]["DateExam"]; ?></td>
          <td><?php echo $result[$k]["StartTime"]; ?></td>
          <td><?php echo $result[$k]["UploadTime"]; ?></td>
     
          
          <td>
          <!-- <a class="btnEditAction" href="edit_exam.php?id=<?php //echo $result[$k]["ModCode"]; ?>">Edit</a>  --><!-- <a class="btnDeleteAction" href="delete.php?action=delete&id=<?php //echo $result[$k]["ModCode"]; ?>">Delete</a> -->
          </td>
          </tr>
          <?php
              }
             }
                    }
          if(isset($result["perpage"])) {
          ?>
          <tr>
          <td colspan="6" align=right> <?php echo $result["perpage"]; ?></td>
          </tr>
          <?php } ?>
        <tbody>
      </table>
      </form> 
    </div>