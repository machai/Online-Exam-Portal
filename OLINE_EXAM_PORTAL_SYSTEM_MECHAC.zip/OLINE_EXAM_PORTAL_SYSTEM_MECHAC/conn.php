<?php
	$conn = new PDO( 'mysql:host=localhost;dbname=exam', 'root', '');
	if(!$conn){
		die("Fatal Error: Connection Failed!");
	}
?>