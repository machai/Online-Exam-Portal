<?php
require_once("dbcontroller.php");
$db_handle = new DBController();
if(!empty($_POST["submit"])) {
    $query = "UPDATE module set module_name = '".$_POST["module_name"]."' WHERE  module_code =".$_GET["id"];

    
    $result = $db_handle->executeQuery($query);
	if(!$result){
		$message = "Problem in Editing! Please Retry!";
	} else {
	echo '<script>alert("Module is succefully updated")</script>';
		//header("Location:student_data.php");
		require_once("module_data.php");
	}

}
$result = $db_handle->runQuery("SELECT * FROM module WHERE module_code='" . $_GET["id"] . "'");
?>
<link href="style.css" type="text/css" rel="stylesheet" />
<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
<script>
// function validate() {
// 	var valid = true;	
// 	$(".demoInputBox").css('background-color','');
// 	$(".info").html('');
	
// 	if(!$("#student_name").val()) {
// 		$("#Student_Name-info").html("(required)");
// 		$("#Student_Name").css('background-color','#FFFFDF');
// 		valid = false;
// 	}
// 	if(!$("#Student_Surname").val()) {
// 		$("#Student_Surname-info").html("(required)");
// 		$("#Student_Surname").css('background-color','#FFFFDF');
// 		valid = false;
// 	}
// 	if(!$("#Email_Address").val()) {
// 		$("#Email_Address-info").html("(required)");
// 		$("#Email_Address").css('background-color','#FFFFDF');
// 		valid = false;
// 	}
// 	if(!$("#price").val()) {
// 		$("#price-info").html("(required)");
// 		$("#price").css('background-color','#FFFFDF');
// 		valid = false;
// 	}	
// 	if(!$("#stock_count").val()) {
// 		$("#stock_count-info").html("(required)");
// 		$("#stock_count").css('background-color','#FFFFDF');
// 		valid = false;
// 	}	
// 	return valid;
// }
</script>
<form name="frmToy" method="post" action="" id="frmToy" onClick="return validate();">
<!-- <div id="mail-status"></div> -->

<div>
<label style="padding-top:20px;">Module Name</label>
<span id="module_name-info" class="info"></span><br/>
<input type="text" name="module_name" id="module_name" class="demoInputBox" value="<?php echo $result[0]["module_name"]; ?>">
</div>


<input type="submit" name="submit" id="btnAddAction" value="Save" />
</div>
</div>
