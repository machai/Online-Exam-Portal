<?php

include("header.php");

$report = new Reports();

$chartData = $report->rpt_predictive();
// rsort($chartData);

$arrWeekdays = array('', "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday");

?>

<!-- Page Content -->
<div class="container">
    <div class="row">
        <!-- Sidebar -->
        <?php include("sidebar.php"); ?>
        <div class="col-lg-9">
            <h4><i class="fa fa-dashboard"></i> Welcome To Admin Area</h4>
            <hr>
            <div class="card mx-auto">
                <div class="card-body">
                	<div>Predictive Report charts</div>
                  <canvas id="myChart" width="600" height="350"></canvas>
                </div>
            </div>

            <div class="card mx-auto">
                <div class="card-body">

                <ul class="nav nav-tabs" id="myTab" role="tablist">
                  <li class="nav-item">
                    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Trends Report</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Exception Reports</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false">Predictive Reports</a>
                  </li>
                </ul>

                <div class="tab-content" id="myTabContent">
                  <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
          
                        <div>
                            <table border="1" class="table">
                                <tr><th colspan="2">Trends Report One</th></tr>
                                <th>TOTAL MODULES</th><th>PER WEEK</th>
                                <?php foreach($report->report_trends1() as $item): ?>
                                <tr>
                                    <td><?php echo $item->TOTAL_MODULES; ?></td>
                                    <td><?php echo $arrWeekdays[$item->PER_WEEK]; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </table>
                        </div>

                       <div>
                            <table border="1" class="table">
                                <tr><th colspan="2">Trends Report Two</th></tr>
                                <th>TOTAL COUNT</th><th>WEEKS NUMBER</th>
                                <?php foreach($report->report_trends2() as $item): ?>
                                <tr>
                                    <td><?php echo $item->TOTAL_COUNT; ?></td>
                                    <td><?php echo $arrWeekdays[$item->WEEKS_NUMBER]; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </table>
                        </div>
                        <div>
                            <table border="1" class="table">
                                <tr><th colspan="2">Trends Report Three</th></tr>
                                <th>Exam Type</th><th>Exam Times</th>
                                <?php foreach($report->report_trends3() as $item): ?>
                                <tr>
                                    <td><?php echo $item->ExamType; ?></td>
                                    <td><?php echo $item->TIMES; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </table>
                        </div>
                  </div>
                
                    <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
        
                        <div>
                            <table border="1" class="table">
                                <tr><th colspan="2">Exception Reports One</th></tr>
                                <th>TOTAL RECORDS</th><th>EXAM DATES</th>
                                <?php foreach($report->rpt_exception1() as $item): ?>
                                <tr>
                                    <td><?php echo $item->TOTAL_RECORDS; ?></td>
                                    <td><?php echo $item->EXAM_DATES; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </table>
                        </div>
                        <div>
                            <table border="1" class="table">
                                <tr><th colspan="2">Exception Reports Two</th></tr>
                                <th>TOTAL COUNT</th><th>MODULES</th>
                                <?php foreach($report->rpt_exception2() as $item): ?>
                                <tr>
                                    <td><?php echo $item->TOTAL_COUNT; ?></td>
                                    <td><?php echo $item->MODULES; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </table>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                        <div>
                            <table border="1" class="table">
                                <tr><th colspan="2">Predictive Reports</th></tr>
                                <th>TOTAL COUNT</th><th>EXAMS SUBMISSIONS</th>
                                <?php foreach($report->rpt_predictive() as $item): ?>
                                <tr>
                                    <td><?php echo $item->TOTAL_COUNT; ?></td>
                                    <td><?php echo $item->EXAMS_SUBMISSIONS; ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </table>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>  
    </div>
</div>
<script src="assets/vendor/Chart.js/Chart.min.js"></script>
<script src="assets/vendor/jquery/jquery.min.js"></script>
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


<script type="text/javascript">

    function displayChart() {
      let ctx = document.getElementById('myChart').getContext('2d');
      var server_data = <?php echo json_encode($chartData); ?>;
      //declare empty arrays
      const monthNames = [];
      // let MinLevel = [];
      let totalSubmissions = [];
      //loop over json array object data
      server_data.forEach(function(v) {
        monthNames.push(v.EXAMS_SUBMISSIONS);
        // MinLevel.push(v.MIN_LEVELS);
        totalSubmissions.push(v.TOTAL_COUNT);
      });
      //prepare chart to display data
      let myChart = new Chart(ctx, {
        type: 'horizontalBar',
        data: {
          labels: monthNames, //chart labels
          datasets: [{
            label: 'Total Submissions',
            data: totalSubmissions, //chart data
            fill: false,
            backgroundColor: ["#5f51b5", "#5f51b5", "#5f51b5", "#5f51b5", "#5f51b5", "#5f51b5", "#5f51b5", "#5f51b5", "#5f51b5", "#5f51b5", "#5f51b5", "#5f51b5"],
            borderColor: ["#f44336", "#f44336", "#f44336", "#f44336", "#f44336", "#f44336", "#f44336", "#f44336", "#f44336", "#f44336", "#f44336", "#f44336", "#f44336"],
            borderWidth: 1
            },
            
        }
      });
    }
    displayChart();
</script>