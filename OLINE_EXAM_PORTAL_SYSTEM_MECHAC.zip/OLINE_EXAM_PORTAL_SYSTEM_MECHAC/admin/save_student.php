<?php
//session_start();

// define variables and set to empty values
$nameErr = $emailErr = $idError = $Numerror = "";
//$name = $email = $gender = $comment = $website = "";
//connect to database here
include('connect.php');
$a = $_POST['student_number'];
$b = $_POST['student_name'];
$c = $_POST['student_surname'];
$d = $_POST['student_email'];

// validating student number 10 number allowed
if(empty($a)){
	
	$idError = "This field cannot be empty";
  
  
  } elseif(strlen($a)< 8){
    
	$idError = "please enter valid student number minum 8 ";	
}
// validating number format
  if(empty($f)){
	
	$Numerror = "This field cannot be empty ";
	
  }elseif(strlen($f)< 10){
	  
	$Numerror = "please enter valid id number minumum 10 ";
}

	
  //}
	
// query
$sql = "INSERT INTO student (student_number,student_name,student_surname,student_email) VALUES (:a,:b,:c,:d)";
$q = $db->prepare($sql);
$q->execute(array(':a'=>$a,':b'=>$b,':c'=>$c,':d'=>$d));

//header("location: student_data.php");
include('student_data.php');
echo '<script>alert("Student is succefully added")</script>';
		//header("Location:student_data.php");
		require_once("student_data.php");

?>