<?php
// contains our functions 
// include('database.php');

class Reports extends DBConnect {
    private $conn = null;

    public function __construct() {
        $this->conn = parent::connect();
    }

    public function report_summ1() {
        $stmt = $this->conn->prepare("SELECT
                        COUNT(id) 'TOTAL_COUNT',
                        DAYNAME(exam_date) 'SUBMIT_DAY'
                        FROM `examinfo`
                        WHERE NULLIF(exam_date,' ') IS NOT NULL
                        GROUP BY SUBMIT_DAY");
        $stmt->execute();
        if($stmt->rowCount() > 0) {
            return $stmt->fetchAll(PDO::FETCH_OBJ);
        }
        else {
            return false;
        }
    }

    public function report_summ2() {
        $stmt = $this->conn->prepare("SELECT
                                COUNT(id) 'TOTAL_COUNT',
                                module_code 'MODULES',
                                DAYNAME(exam_date) 'DAYS'
                                FROM `examinfo`
                                WHERE NULLIF(exam_date,' ') IS NOT NULL
                                GROUP BY DAYS
                                HAVING TOTAL_COUNT >= 1");
        $stmt->execute();
        if($stmt->rowCount() > 0) {
            return $stmt->fetchAll(PDO::FETCH_OBJ);
        }
        else {
            return false;
        }
    }

    public function report_trends1() {
        $stmt = $this->conn->prepare("SELECT COUNT(module_code) AS 'TOTAL_MODULES',
                                    WEEKDAY(exam_date)+1 AS 'PER_WEEK'
                                    FROM `examinfo`
                                    WHERE exam_date <> ''
                                    GROUP BY PER_WEEK");
        $stmt->execute();
        if($stmt->rowCount() > 0) {
            return $stmt->fetchAll(PDO::FETCH_OBJ);
        }
        else {
            return false;
        }
    }

    public function report_trends2() {
        $stmt = $this->conn->prepare("SELECT COUNT(module_code) 'TOTAL_COUNT',
                                    WEEKDAY(exam_date)+1 AS 'WEEKS_NUMBER'
                                    FROM `examinfo`
                                    WHERE exam_date <> ''
                                    GROUP BY WEEKS_NUMBER
                                    HAVING TOTAL_COUNT > 1");
        $stmt->execute();
        if($stmt->rowCount() > 0) {
            return $stmt->fetchAll(PDO::FETCH_OBJ);
        }
        else {
            return false;
        }
    }

    public function report_trends3() {
        $stmt = $this->conn->prepare("SELECT b.exam_type AS 'ExamType', b.start_time AS 'TIMES'
                                    FROM `exams` a LEFT JOIN `examinfo` b
                                    ON a.id = b.id
                                    WHERE b.exam_type = 'file-upload' 
                                    AND extract(hour from b.start_time) in ('08','11')
                                    GROUP BY TIMES
                                    ORDER BY TIMES ASC LIMIT 10");
        $stmt->execute();
        if($stmt->rowCount() > 0) {
            return $stmt->fetchAll(PDO::FETCH_OBJ);
        }
        else {
            return false;
        }
    }

    public function rpt_exception1() {
        $stmt = $this->conn->prepare("SELECT COUNT(a.id) 'TOTAL_RECORDS',
                                        b.exam_date 'EXAM_DATES'
                                        FROM `exams` a LEFT JOIN `examinfo` b
                                        ON a.module_code = b.module_code
                                        WHERE NULLIF(b.exam_date,' ') IS NULL");
        $stmt->execute();
        if($stmt->rowCount() > 0) {
            return $stmt->fetchAll(PDO::FETCH_OBJ);
        }
        else {
            return false;
        }
    }

    public function rpt_exception2() {
        $stmt = $this->conn->prepare("SELECT COUNT(id) AS 'TOTAL_COUNT',
                                        module_code AS 'MODULES'
                                        FROM `exams`
                                        GROUP BY module_code
                                        HAVING COUNT(module_code) > 1 LIMIT 10");
        $stmt->execute();
        if($stmt->rowCount() > 0) {
            return $stmt->fetchAll(PDO::FETCH_OBJ);
        }
        else {
            return false;
        }
    }

    public function rpt_predictive() {
        $stmt = $this->conn->prepare("SELECT COUNT(id) 'TOTAL_COUNT',
                                    MONTHNAME(exam_date) 'EXAMS_SUBMISSIONS'
                                    FROM `examinfo`
                                    WHERE NULLIF(exam_date, '') IS NOT NULL
                                    GROUP BY EXAMS_SUBMISSIONS
                                    ORDER BY exam_date");
        $stmt->execute();
        if($stmt->rowCount() > 0) {
            return $stmt->fetchAll(PDO::FETCH_OBJ);
        }
        else {
            return false;
        }
    }

    /*function get_total_submissions(){
        global $db;
        $result = $db->query("SELECT COUNT(*) AS NUM_SUBMISSION FROM exams")->fetchColumn();
        return $result;
    }

    function get_student_reg_for_each_mod(){
        global $db;
        $result = $db->query("SELECT DISTINCT module_code, COUNT(module_code) AS NUM_STUDENTS FROM enrollment GROUP BY module_code;");
        return $result;
    }

    function get_stud_with_multiple_sub(){
        global $db;
        $result = $db->query("SELECT DISTINCT student_number, module_code, count(module_code) AS 'SUBMISSION'
        FROM exams 
        GROUP BY student_number 
        ORDER BY count(module_code) DESC");
        return $result;
    }

    function get_total_number_of_submissions(){
        global $db;
        $result = $db->query("select COUNT(*) AS NUM_SUBMISSION FROM exams")->fetchColumn();
        return $result;
    }
        
    function get_student_reg_for_each_module(){
        global $db;
        $result = $db->query("SELECT DISTINCT module_code, COUNT(module_code) AS NUM_STUDENTS FROM enrollment GROUP BY module_code;");
        return $result;
    }

    function get_student_with_multiple_sub(){
        global $db;
        $result = $db->query("SELECT DISTINCT student_number, module_code, count(module_code) AS 'SUBMISSION'
        FROM exams
        GROUP BY student_number
        ORDER BY count(module_code) DESC");
        return $result;
    }

    function get_total_number_of_registered_students(){
        $sql = "select COUNT(*) AS NUM_STUDENTS FROM student";
        $query = $this->db->prepare($sql);
        $query->execute();
        $result = $query->fetchAll();
        return $result;
    }*/

}

?>