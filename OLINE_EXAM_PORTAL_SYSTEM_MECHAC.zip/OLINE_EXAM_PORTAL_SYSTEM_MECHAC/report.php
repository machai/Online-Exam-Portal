<?php
require('connection.php'); // connection to db

$sql = $db->prepare ("SELECT COUNT(Student_Number) 'Count_number', Course_Code 'Module', Student_Number 'Students' FROM `exam_type` GROUP BY Student_Number HAVING COUNT(MODULE) >= 5");
$sql->setFetchMode(PDO::FETCH_ASSOC) ;
$sql->execute();

if($sql->rowCount() != 0) {
?>
<h3>Report for all the records for students that submitted more than 5 same module</h3>
<table border="1">
   <tr COLSPAN=1 BGCOLOR="#ffb366">
     <td>Count number</td>
      <td>Course</td>
      <td>Students</td>
   </tr>
 <?php     
 while($row=$sql->fetch()) 
 {
      echo "<tr>".
       "<td>".$row["Count_number"]."</td>".
           "<td>".$row["Module"]."</td>".
           "<td>".$row["Students"]."</td>".
           "</tr>";
 }

}
else
{
     echo "don't exist records for list on the table";
}

?>