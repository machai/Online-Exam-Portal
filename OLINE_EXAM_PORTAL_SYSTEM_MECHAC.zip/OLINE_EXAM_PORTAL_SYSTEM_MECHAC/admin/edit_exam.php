<?php
require_once("dbcontroller.php");
$db_handle = new DBController();
if(!empty($_POST["submit"])) {
    $query = "UPDATE examinfo set module_code = '".$_POST["module_code"]."',exam_type = '".$_POST["exam_type"]."', exam_date = '".$_POST["exam_date"]."', start_time = '".$_POST["start_time"]."', completion_time = '".$_POST["completion_time"]."' WHERE  module_code =".$_GET["id"];
    $result = $db_handle->executeQuery($query);
	if(!$result){
		$message = "Problem in Editing! Please Retry!";
	} else {

		header("Location:student_data.php");
	}

}
$result = $db_handle->runQuery("SELECT * FROM examinfo WHERE module_code='" . $_GET["id"] . "'");
?>
<link href="style.css" type="text/css" rel="stylesheet" />
<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
<script>
	
// function validate() {
// 	var valid = true;	
// 	$(".demoInputBox").css('background-color','');
// 	$(".info").html('');
	
// 	if(!$("#exam_type").val()) {
// 		$("#exam_type-info").html("(required)");
// 		$("#exam_type").css('background-color','#FFFFDF');
// 		valid = false;
// 	}
// 	if(!$("#exam_date").val()) {
// 		$("#exam_date-info").html("(required)");
// 		$("#exam_date").css('background-color','#FFFFDF');
// 		valid = false;
// 	}
// 	if(!$("#start_time").val()) {
// 		$("#start_time-info").html("(required)");
// 		$("#start_time").css('background-color','#FFFFDF');
// 		valid = false;
// 	}
// 	if(!$("#Email Address").val()) {
// 		$("#Email Address-info").html("(required)");
// 		$("#Email Address").css('background-color','#FFFFDF');
// 		valid = false;
// 	}	
// 	if(!$("#stock_count").val()) {
// 		$("#stock_count-info").html("(required)");
// 		$("#stock_count").css('background-color','#FFFFDF');
// 		valid = false;
// 	}	
// 	return valid;
// }
</script>
<form name="frmToy" method="post" action="" id="frmToy" >
<!-- <div id="mail-status"></div> -->

<div>
<label>Module Code</label>
<span id="module_code-info" class="info"></span><br/>
<input type="text" name="module_code" id="module_code" class="demoInputBox" value="<?php echo $result[0]["module_code"]; ?>">
</div>

<div>
<label style="padding-top:20px;">Exam type</label>
<span id="exam_type-info" class="info"></span><br/>
<input type="text" name="exam_type" id="exam_type" class="demoInputBox" value="<?php echo $result[0]["exam_type"]; ?>">
</div>
<div>
<label>Exam date</label>
<span id="exam_date-info" class="info"></span><br/>
<input type="text" name="exam_date" id="exam_date" class="demoInputBox" value="<?php echo $result[0]["exam_date"]; ?>">
</div>

<div>
<label>Start_time</label>
<span id="start_time-info" class="info"></span><br/>
<input type="text" name="start_time" id="start_time" class="demoInputBox" value="<?php echo $result[0]["start_time"]; ?>">
</div> 

<div>
<label>Completion Time</label> 
<span id="completion_time-info" class="info"></span><br/>
<input type="text" name="completion_time" id="completion_time" class="demoInputBox" value="<?php echo $result[0]["completion_time"]; ?>">
</div>

<input type="submit" name="submit" id="btnAddAction" value="Save" />

</div>
</div>
