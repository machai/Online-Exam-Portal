<?php
require_once("dbcontroller.php");
$db_handle = new DBController();
if(!empty($_POST["submit"])) {
    $query = "UPDATE studentinfo set StudentName = '".$_POST["StudentName"]."', student_surname = '".$_POST["student_surname"]."', StudentEmail = '".$_POST["StudentEmail"]."' WHERE  StudentNumber =".$_GET["id"];
    $result = $db_handle->executeQuery($query);
	if(!$result){
		$message = "Problem in Editing! Please Retry!";
	} else {
	echo '<script>alert("Student is succefully updated")</script>';
		//header("Location:student_data.php");
		require_once("dash.php");
	}

}
$result = $db_handle->runQuery("SELECT * FROM studentinfo WHERE StudentNumber='" . $_GET["id"] . "'");
?>
<link href="style.css" type="text/css" rel="stylesheet" />
<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
<script>
// function validate() {
// 	var valid = true;	
// 	$(".demoInputBox").css('background-color','');
// 	$(".info").html('');
	
// 	if(!$("#StudentName").val()) {
// 		$("#StudentName-info").html("(required)");
// 		$("#StudentName").css('background-color','#FFFFDF');
// 		valid = false;
// 	}
// 	if(!$("#Student_Surname").val()) {
// 		$("#Student_Surname-info").html("(required)");
// 		$("#Student_Surname").css('background-color','#FFFFDF');
// 		valid = false;
// 	}
// 	if(!$("#Email_Address").val()) {
// 		$("#Email_Address-info").html("(required)");
// 		$("#Email_Address").css('background-color','#FFFFDF');
// 		valid = false;
// 	}
// 	if(!$("#price").val()) {
// 		$("#price-info").html("(required)");
// 		$("#price").css('background-color','#FFFFDF');
// 		valid = false;
// 	}	
// 	if(!$("#stock_count").val()) {
// 		$("#stock_count-info").html("(required)");
// 		$("#stock_count").css('background-color','#FFFFDF');
// 		valid = false;
// 	}	
// 	return valid;
// }
</script>
<form name="frmToy" method="post" action="" id="frmToy" onClick="return validate();">
<!-- <div id="mail-status"></div> -->

<div>
<label style="padding-top:20px;">Student Name</label>
<span id="StudentName-info" class="info"></span><br/>
<input type="text" name="StudentName" id="StudentName" class="demoInputBox" value="<?php echo $result[0]["StudentName"]; ?>">
</div>
<!-- <div>
<label>Student Surname</label>
<span id="student_surname-info" class="info"></span><br/>
<input type="text" name="student_surname" id="student_surname" class="demoInputBox" value="<?php //echo $result[0]["student_surname"]; ?>">
</div> -->

<!-- <div>
<label>Student Number</label>
<span id="Student_Surname-info" class="info"></span><br/>
<input type="text" name="Student_Surname" id="Student_Surname" class="demoInputBox" value="<?php //echo $result[0]["Student_Number"]; ?>">
</div>
 -->
<div>
<label>Email Address</label> 
<span id="StudentEmail-info" class="info"></span><br/>
<input type="text" name="StudentEmail" id="StudentEmail" class="demoInputBox" value="<?php echo $result[0]["StudentEmail"]; ?>">
</div>

<input type="submit" name="submit" id="btnAddAction" value="Save" />
</div>
</div>
