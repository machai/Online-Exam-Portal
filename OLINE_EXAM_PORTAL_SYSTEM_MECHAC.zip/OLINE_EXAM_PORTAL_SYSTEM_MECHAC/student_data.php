<?php
//include auth_session.php file on all user panel pages
include("auth_session.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Student Management</title>
    <link rel="stylesheet" href="style.css" />

    <style>

  .rectangle {
  height: 50px;
  width: 270px;
  background-color: #85c1e9;

}
</style>
</head>


<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body>

<div class="w3-sidebar w3-bar-block w3-light-grey" style="width:20%">
  <div class="w3-container w3-dark-grey">
    <h4> Message Of The Day</h4>
  </div>

  <img src="logo.jpg" alt="Snow" style="width:30%">
  <a href="dashboard.php" class="w3-bar-item w3-button w3-red">Home</a>
  <a href="exam.php" class="w3-bar-item w3-button">Exams <span class="w3-tag w3-red w3-right w3-margin-right">2</span></a>
  <a href="student_data.php" class="w3-bar-item w3-button">Student Management</a>
  <a href="#" class="w3-bar-item w3-button">Acknowledgements</a>
    <a href="more_report.php" class="w3-bar-item w3-button">More reports</a>

  <div class="w3-panel w3-blue-grey w3-display-container">
    <span onclick="this.parentElement.style.display='none'" class="w3-button w3-blue-grey w3-display-topright">&times;</span>
    <p>June/July 2021 MCQ Examinations:</p>
  </div>

</div>

<div style="margin-left:20%">


<div class="w3-container">
<body>
    <div class="form">
      


<html>
<head>
<title>PHP Multiple Choice Questions and Answers</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>
<div class="container">
<h1>Multiple Choice Questions Answers</h1>
<p>Please fill the details and answers the all questions-</p>
<form action="score.php" method="post">
<div class="form-group">
<strong>Name*:</strong><br/>
 <input type="text" name="name" value="" required/>
</div>
<div class="form-group">
<strong>Age*:</strong><br/> 
<input type="text" name="age" value="" required/>
</div>
<div class="form-group">
<strong>Phone*:</strong><br/> 
<input type="text" name="phone" value="" required/>
</div>
<h3>Ques1 : Who is the father of PHP? </h3>
<div class="form-group"> 
<ol>
<li>
<input type="radio" name="q1" value="1" />Rasmus Lerdorf
</li>
<li>
<input type="radio" name="q1" value="2" />Larry Wall
</li>
<li>
<input type="radio" name="q1" value="3" />Zeev Suraski
</li>
</ol>
</div>
<br/>
<div class="form-group"> 
<h3>Ques2 : Which of the functions is used to sort an array in descending order?</h3>
<ol>
<li>
<input type="radio" name="q2" value="1" />sort()
</li>
<li>
<input type="radio" name="q2" value="2" />asort()
</li>
<li>
<input type="radio" name="q2" value="3" />rsort()
</li>
</ol>
</div>
<br/>
<div class="form-group"> 
<h3>Ques3 : Which version of PHP introduced the instanceof keyword?</h3>
<ol>
<li>
<input type="radio" name="q3" value="1" />PHP 4 
</li>
<li>
<input type="radio" name="q3" value="2" />PHP 5
</li>
<li>
<input type="radio" name="q3" value="3" />PHP 6
</li>
</ol>
</div>
<div class="form-group">
<input type="submit" value="Submit" name="submit" class="btn btn-primary"/>
</div>
</form>
</div>
</body>
</html>

</body>
</html>