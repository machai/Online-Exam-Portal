<?php
//include auth_session.php file on all user panel pages
include("auth_session.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Student Management</title>
    <link rel="stylesheet" href="style.css" />

    <style>

  .rectangle {
  height: 50px;
  width: 270px;
  background-color: #85c1e9;

}
</style>
</head>


<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body>

<div class="w3-sidebar w3-bar-block w3-light-grey" style="width:20%">
  <div class="w3-container w3-dark-grey">
    <h4> Message Of The Day</h4>
  </div>

  <img src="logo.jpg" alt="Snow" style="width:30%">
  <a href="dashboard.php" class="w3-bar-item w3-button w3-red">Home</a>
  <a href="exam.php" class="w3-bar-item w3-button">Exams <span class="w3-tag w3-red w3-right w3-margin-right">2</span></a>
  <a href="student_data.php" class="w3-bar-item w3-button">Student Management</a>
  <a href="#" class="w3-bar-item w3-button">Acknowledgements</a>
    <a href="more_report.php" class="w3-bar-item w3-button">More reports</a>

  <div class="w3-panel w3-blue-grey w3-display-container">
    <span onclick="this.parentElement.style.display='none'" class="w3-button w3-blue-grey w3-display-topright">&times;</span>
    <p>June/July 2021 MCQ Examinations:</p>
  </div>

</div>

<div style="margin-left:20%">


<div class="w3-container">
<body>
    <div class="form">


<?php 
if($_POST['submit']) {
    $name = $_POST['name'];
	$age = $_POST['age'];
	$phone = $_POST['phone'];
	if($name == '' || $age == '' || $phone == '') {
		echo '<h2>Please fill all * mandatory fields.</h2>';
	}	

	if($q1=='' || $q2 =='' || $q3 =='')
    $q1 = $_POST['q1'];
	$q2 = $_POST['q2'];
	$q3 = $_POST['q3'];


	if($q1=='' || $q2 =='' || $q3 =='') {
		echo '<h2>Please answer all questions.</h2>';
	}
	else {
		$score = 0;
		if($q1 == 1) { // 1st option is correct
		$score++;
		}
		if($q2 == 3) { // 3rd option is correct
		$score++;
		}
		if($q3 == 2) { // 2nd option is correct
		$score++;
		}
	        $score = $score	/ 3 *100;
		
		if($score < 50)
		{
		echo '<h2>You need to score at least 50% to pass the exam.</h2>';
		}
		else {
		echo '<h2>You have passed the exam and scored '.$score.'%.</h2>';
		}
	}
}
?>