<?php
//session_start();

// define variables and set to empty values
$nameErr = $emailErr = $idError = $Numerror = "";
//$name = $email = $gender = $comment = $website = "";
//connect to database here
include('connect.php');
$a = $_POST['module_code'];
$b = $_POST['module_name'];

// validating student number 10 number allowed
if(empty($a)){
	
	$idError = "This field cannot be empty";
  
  
  } elseif(strlen($a)< 10){
    
	$idError = "please enter valid student number minum 10 ";	
}
// validating number format
  if(empty($f)){
	
	$Numerror = "This field cannot be empty ";
	
  }elseif(strlen($f)< 10){
	  
	$Numerror = "please enter valid id number minumum 10 ";
}

	
  //}
	
// query
$sql = "INSERT INTO module (module_code,module_name) VALUES (:a,:b)";
$q = $db->prepare($sql);
$q->execute(array(':a'=>$a,':b'=>$b));

//header("location: student_data.php");

echo '<script>alert("Module is succefully added")</script>';
		//header("Location:student_data.php");
		require_once("module_data.php");

?>