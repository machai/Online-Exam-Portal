
    
<style>
    
table,th, td {
  border: 1px solid #D3F5B8;

/*  background-color: #96D4D4;*/
  /*border-collapse: collapse;*/
   width: 80%;
}
th, td {
  background-color: #96D4D4;
}
/*tr {
  background-color: #96D4D4;
}*/


</style>



<?php
require('connection.php'); // connection to db

$sql = $db->prepare ("SELECT
                        COUNT(ModCode) 'TOTAL_COUNT',
                        DAYNAME(DateExam) 'SUBMIT_DAY'
                        FROM `exam_output`
                        WHERE NULLIF(DateExam,' ') IS NOT NULL
                        GROUP BY SUBMIT_DAY");
$sql->setFetchMode(PDO::FETCH_ASSOC) ;
$sql->execute();

if($sql->rowCount() != 0) {
?>



<table >
   <tr >
    <h3>Trends Daily Report</h3>
     <td>Count number</td>
      <td>Submitted day</td>
      
   </tr>

 <?php     
 while($row=$sql->fetch()) 
 {
      echo "<tr>".
       "<td>".$row["TOTAL_COUNT"]."</td>".
           "<td>".$row["SUBMIT_DAY"]."</td>".
      
           "</tr>";
 }

}
else
{
     echo "don't exist records for list on the table";
}

// second report start here
//echo '<br>'.'<br>';

require('connection.php'); // connection to db

$sql = $db->prepare ("SELECT
                                COUNT(ModCode) 'TOTAL_COUNT',
                                ModCode 'MODULES',
                                DAYNAME(DateExam) 'DAYS'
                                FROM `examsetup`
                                WHERE NULLIF(DateExam,' ') IS NOT NULL
                                GROUP BY DAYS
                                HAVING TOTAL_COUNT >= 1");
$sql->setFetchMode(PDO::FETCH_ASSOC) ;
$sql->execute();

if($sql->rowCount() != 0) {

?>
<?php echo '<br>'.'<br>';?>



<table border="1">
   <tr COLSPAN=1 BGCOLOR="#ffb366">
    <h3>Trends Weekly Report</h3>
     <td>Total count</td>
      <td>Modules</td>
      <td>Day</td>
   </tr>
 <?php     
 while($row=$sql->fetch()) 
 {
      echo "<tr>".
       "<td>".$row["TOTAL_COUNT"]."</td>".
           "<td>".$row["MODULES"]."</td>".
           "<td>".$row["DAYS"]."</td>".
           "</tr>";
 }

}
else
{
     echo "don't exist records for list on the table";
}



// third report start here
//echo '<br>'.'<br>';

// require('connection.php'); // connection to db

// $sql = $db->prepare ("SELECT b.exam_type AS 'ExamType', b.start_time AS 'TIMES'
//                                     FROM `exams` a LEFT JOIN `examinfo` b
//                                     ON a.id = b.id
//                                     WHERE b.exam_type = 'file-upload' 
//                                     AND extract(hour from b.start_time) in ('08','11')
//                                     GROUP BY TIMES
//                                     ORDER BY TIMES ASC LIMIT 10");
// $sql->setFetchMode(PDO::FETCH_ASSOC) ;
// $sql->execute();

// if($sql->rowCount() != 0) {

// ?>
 <?php //echo '<br>'.'<br>';?>




  <?php     
//  while($row=$sql->fetch()) 
//  {
//       echo "<tr>".
//        "<td>".$row["ExamType"]."</td>".
//            "<td>".$row["TIMES"]."</td>".
          
//            "</tr>";
//  }

// }
// else
// {
//      echo "don't exist records for list on the table";
// }


require('connection.php'); // connection to db

$sql = $db->prepare("SELECT studentinfo.StudentNumber,StudentName,exam_output.ModCode, COUNT(studentinfo.StudentNumber) AS 'Total_Count' FROM studentinfo INNER JOIN exam_output ON exam_output.StudentNumber= studentinfo.StudentNumber WHERE exam_output.ModCode LIKE 'ICT%' OR exam_output.ModCode LIKE 'ict%' GROUP BY exam_output.ModCode HAVING COUNT(exam_output.StudentNumber) > 3 ORDER BY StudentNumber");
$sql->setFetchMode(PDO::FETCH_ASSOC) ;
$sql->execute();

if($sql->rowCount() != 0) {


?>
 <?php echo '<br>'.'<br>';?>



 <table border="1">
    <tr COLSPAN=1 BGCOLOR="#ffb366">
    <h3>Trends Summary report </h3>
    <td>Student Number</td>
      <td>Student Name</td>
       <td>Module Code</td>
        <td>Total Count</td>
     
    </tr>
 <?php     
  while($row=$sql->fetch()) 
  {
       echo "<tr>".
        "<td>".$row["StudentNumber"]."</td>".
           "<td>".$row["StudentName"]."</td>".
            "<td>".$row["ModCode"]."</td>".
             "<td>".$row["Total_Count"]."</td>".
          
           "</tr>";
  }

 }
 else
 {
      echo "don't exist records for list on the table";
 }



// Pedictive report report start here
//echo '<br>'.'<br>';

require('connection.php'); // connection to db

$sql = $db->prepare ("SELECT COUNT(TransactionID) 'TOTAL_COUNT',
                                    MONTHNAME(DateExam) 'EXAMS_SUBMISSIONS'
                                    FROM `exam_output`
                                    WHERE NULLIF(DateExam, '') IS NOT NULL
                                    GROUP BY EXAMS_SUBMISSIONS
                                    ORDER BY DateExam");
$sql->setFetchMode(PDO::FETCH_ASSOC) ;
$sql->execute();

if($sql->rowCount() != 0) {

?>
<?php echo '<br>'.'<br>';?>



<table border="1">
   <tr COLSPAN=1 BGCOLOR="#ffb366">
<h3>Predictive Report </h3>
     <td>Total</td>
      <td>Exam Submission</td>
     
   </tr>
 <?php     
 while($row=$sql->fetch()) 
 {
      echo "<tr>".
       "<td>".$row["TOTAL_COUNT"]."</td>".
           "<td>".$row["EXAMS_SUBMISSIONS"]."</td>".
          
           "</tr>";
 }

}
else
{
     echo "don't exist records for list on the table";
}




?>