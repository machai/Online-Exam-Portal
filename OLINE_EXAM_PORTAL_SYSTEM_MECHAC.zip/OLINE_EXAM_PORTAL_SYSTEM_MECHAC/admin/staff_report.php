<?php  
//connect to database
$con = mysqli_connect('localhost', 'root', '');
       mysqli_select_db($con, 'exam');
	   
	 
	   //find out the number of results stored in bd
	   
	   $sql ="SELECT * FROM staffinfo";
	   $result = mysqli_query($con,$sql);
	   echo '<b>'. $results_number = mysqli_num_rows($result) .'</b>'.' Staff';
	   

	   

?>