<?php
//include auth_session.php file on all user panel pages
include("auth_session.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Exam Management</title>
    <link rel="stylesheet" href="style.css" />

    <style>

  .rectangle {
  height: 50px;
  width: 270px;
  background-color: #85c1e9;


}
</style>
</head>


<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body>

<div class="w3-sidebar w3-bar-block w3-light-grey" style="width:20%">
  <div class="w3-container w3-dark-grey">
    <h4> Message Of The Day</h4>
  </div>

  <img src="logo.jpg" alt="Snow" style="width:30%">
  <a href="dashboard.php" class="w3-bar-item w3-button w3-red">Home</a>
  <a href="exam.php" class="w3-bar-item w3-button">Exams <span class="w3-tag w3-red w3-right w3-margin-right">2</span></a>
  <a href="student_data.php" class="w3-bar-item w3-button">Module Management</a>
  <a href="#" class="w3-bar-item w3-button">Acknowledgements</a>
    <a href="more_report.php" class="w3-bar-item w3-button">More reports</a>

  <div class="w3-panel w3-blue-grey w3-display-container">
    <span onclick="this.parentElement.style.display='none'" class="w3-button w3-blue-grey w3-display-topright">&times;</span>
    <p>June/July 2021 MCQ Examinations:</p>
  </div>

</div>

<div style="margin-left:20%">


<div class="w3-container">
<body>
    <div class="form">
      


<?php
  require_once("perpage.php");  
  require_once("dbcontroller.php");
  $db_handle = new DBController();
  
  $name = "";
  $code = "";
  
  $queryCondition = "";
  if(!empty($_POST["search"])) {
    foreach($_POST["search"] as $k=>$v){
      if(!empty($v)) {

        $queryCases = array("Student_Name","Student_Number");
        if(in_array($k,$queryCases)) {
          if(!empty($queryCondition)) {
            $queryCondition .= " AND ";
          } else {
            $queryCondition .= " WHERE ";
          }
        }
        switch($k) {
          case "Student_Name":
            $name = $v;
            $queryCondition .= "Student_Name LIKE '" . $v . "%'";
            break;
          case "Student_Number":
            $code = $v;
            $queryCondition .= "Student_Number LIKE '" . $v . "%'";
            break;
        }
      }
    }
  }
  //  get student table from database
  $orderby = " ORDER BY Student_Number desc"; 
  $sql = "SELECT * FROM students " . $queryCondition;
  $href = 'student_data.php';          
    
  $perPage = 5; 
  $page = 1;
  if(isset($_POST['page'])){
    $page = $_POST['page'];
  }
  $start = ($page-1)*$perPage;
  if($start < 0) $start = 0;
    
  $query =  $sql . $orderby .  " limit " . $start . "," . $perPage; 
  $result = $db_handle->runQuery($query);
  
  if(!empty($result)) {
    $result["perpage"] = showperpage($sql, $perPage, $href);
  }
?>

  
    <h2>Exam Management</h2>
    <div style="text-align:right;margin:20px 0px 10px;">
    <a id="btnAddAction" href="add.php">Add New</a>
    </div>
    <div id="toys-grid">      
      <form name="frmSearch" method="post" action="student_data.php">
      <div class="search-box">
      <p><input type="text" placeholder="Student Name" name="search[Student_Name]" class="demoInputBox" value="<?php echo $name; ?>"  /><input type="text" placeholder="Student Number" name="search[Student_Number]" class="demoInputBox" value="<?php echo $code; ?>" /><input type="submit" name="go" class="btnSearch" value="Search"><input type="reset" class="btnSearch" value="Reset" onclick="window.location='student_data.php'"></p>
      </div>
      
      <table cellpadding="10" cellspacing="1">
        <thead>
          <tr>
          <th><strong>Student Number</strong></th>  
          <th><strong>Student Name</strong></th>   
          <th><strong>Student Surname</strong></th>
          <th><strong>Email Address</strong></th>
          <th><strong>Action</strong></th>
          
          </tr>
        </thead>
        <tbody>
          <?php
          if(!empty($result)) {
            foreach($result as $k=>$v) {
              if(is_numeric($k)) {
          ?>
          <tr>
          <td><?php echo $result[$k]["Student_Number"]; ?></td>
          <td><?php echo $result[$k]["Student_Name"]; ?></td>
          <td><?php echo $result[$k]["Student_Surname"]; ?></td>
          <td><?php echo $result[$k]["Email_Address"]; ?></td>
          
          <td>
          <a class="btnEditAction" href="edit.php?id=<?php echo $result[$k]["Student_Number"]; ?>">Edit</a> <a class="btnDeleteAction" href="delete.php?action=delete&id=<?php echo $result[$k]["Student_Number"]; ?>">Delete</a>
          </td>
          </tr>
          <?php
              }
             }
                    }
          if(isset($result["perpage"])) {
          ?>
          <tr>
          <td colspan="6" align=right> <?php echo $result["perpage"]; ?></td>
          </tr>
          <?php } ?>
        <tbody>
      </table>
      </form> 
    </div>










    </div>

</body>
</html>