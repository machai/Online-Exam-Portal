<?php
//include auth_session.php file on all user panel pages
include("auth_session.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Dashboard - student area</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
    /* Set height of the grid so .sidenav can be 100% (adjust as needed) */
    .row.content {height: 550px}
    
    /* Set gray background color and 100% height */
    .sidenav {
      background-color: #f1f1f1;
      height: 100%;
    }
        
    /* On small screens, set height to 'auto' for the grid */
    @media screen and (max-width: 767px) {
      .row.content {height: auto;} 

table, th, td {
  border: 1px solid white;
  border-collapse: collapse;
}
th, td {
  background-color: #96D4D4;
}

    }
  </style>
</head>
<body>

<nav class="navbar navbar-inverse visible-xs">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Logo
      </a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="dashboard.php">Dashboard</a></li>
        <li><a href="#">Student Management</a></li>
        <li><a href="#">Gender</a></li>
        <li><a href="#">Geo</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container-fluid">
  <div class="row content">
    <div class="col-sm-3 sidenav hidden-xs">
   <!--    <h2>Logo</h2> -->
       <img src ="graduated.png" alt ="Admin photo" style="width: 100px;height: 80px;">
      <ul class="nav nav-pills nav-stacked">
        <li class="active"><a href="dashboard.php">Dashboard</a></li>
        <li><a href="dash.php">enrolled module</a></li>
        <!-- <li><a href="dash2.php">Module Management</a></li> -->
       <!--  <li><a href="dash3.php">Exam Management</a></li>
        <li><a href="exam_submitted.php">Result Management</a></li>
         <li><a href="dash5.php">Report Management</a></li> -->
        <li> <a href="logout.php">Logout</a></li>
      </ul><br>
    </div>

    
     <div class="col-sm-9">
      <div class="well">
        <h4>Dashboard</h4>
        <!--<p >Hello, <?php //echo $_SESSION['username']; ?>!</p> -->
        <!-- <img src ="img/graduated.png" alt ="Admin photo" style="width: 100px;height: 100px;"> -->
        <!-- <p>Welcome to  UNISA Online Examination System!  Exam Department</p> -->
        <!-- <p><a href="logout.php">Logout</a></p> -->
<?php 
//require_once("exam.php");  





require_once("models/database.php");
require_once("models/adminModel.php");
require_once("models/studentsModel.php");
require_once("models/admissionModel.php");
require_once("models/modulesModel.php");
require_once("models/examsModel.php");
//require_once("models/reportsModel.php");




// $student = new Student();
$admission = new Admission();
$exam = new Exams();
$module = new Modules();




if(isset($_REQUEST['action'])) {

    if($_SERVER['REQUEST_METHOD'] == 'GET') {
        $action = filter_input(INPUT_GET, "action");
    }
    else {
        //get the request
        $action = filter_input(INPUT_POST, "action");
    }

     //processing the above reqeust



 if($action == "student-modules") {
        include("views/modules.php");
    }
    elseif($action == "student-exams") {
        include("views/exams.php");
    }
    elseif($action == "start-exam") {
        include("views/exam_progress.php");
    }
    elseif($action == "exam-submit") {
        $DIR_PATH = "submissions"; //folder name

        $moduleCode = $_REQUEST['exam']; //module code

        $filename = $_FILES['filename']['name']; //file name to be uploaded

        $file_parts = explode('.', $filename); //separate document info in parts

        $file_ext = end($file_parts);

        //rewrite the document file name
        $filename = $_REQUEST['studentNumber']."_".$moduleCode."_".$_REQUEST['date_exam'].'.'.$file_ext;
        //directory full path for upload
        $targetPath = $DIR_PATH."/".$filename;

        if(!is_dir($DIR_PATH)) { //if directory does not exists
            mkdir($DIR_PATH); //else create the directory
        }
        
        if($exam->studentExamSubmission($moduleCode, $_REQUEST['date_exam'], $filename)) {
            if(move_uploaded_file($_FILES['filename']['tmp_name'], $targetPath)) { //move file for upload
                echo "<script>alert('Your examination document has been submitted.')</script>"; //success message
                echo "<script>alert('Document: '".$filename."' has been uploaded.'')</script>";
            }
            else {
                echo "<script>alert('Failed to upload document: ".$filename."')</script>"; //error message on upload fail
            }
        }
        else {
            echo "<script>alert('Failed to submit your exam, please try again.')</script>"; //error message of fail to save
        }
        echo "<script>window.open('?action=end-exam','_self')</script>"; //redirect to page
    }
    elseif($action == "end-exam") {
        include("views/exam_end.php");
    }
}

























?>
 </div>
      </div> 
     
      <div class="row">
        <div class="col-sm-12">
          <div class="well">



          </div>
        </div>
       
      </div>
    </div>
  </div>
</div>

</body>
</html>
