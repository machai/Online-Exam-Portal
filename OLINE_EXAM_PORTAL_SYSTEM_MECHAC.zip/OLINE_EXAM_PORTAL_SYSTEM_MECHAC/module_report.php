<?php  
//connect to database
$con = mysqli_connect('localhost', 'root', '');
       mysqli_select_db($con, '54837154_ict3715_03');
	   
	   // define how many results you need per page
	  // $result_per_page = 10;
	   
	   //find out the number of results stored in bd
	   
	   $sql ="SELECT * FROM course";
	   $result = mysqli_query($con,$sql);
	   echo 'Available Modules in the system '. '<b>'.$results_number = mysqli_num_rows($result) .'</b>'.' Modules';
	   

	   

?>