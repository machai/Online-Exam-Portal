<?php
//include auth_session.php file on all user panel pages
include("auth_session.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Dashboard - Admin area</title>
    <link rel="stylesheet" href="style.css" />

    <style>


  .rectangle {
  height: 50px;
  width: 270px;
  background-color: #85c1e9;

}
</style>
</head>


<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body>

<div class="w3-sidebar w3-bar-block w3-light-grey" style="width:20%">
  <div class="w3-container w3-dark-grey">
    <h4> Message Of The Day</h4>
  </div>

  <img src="logo.jpg" alt="Snow" style="width:30%">
  <a href="dashboard.php" class="w3-bar-item w3-button w3-red">Admin Home</a>
  <a href="#" class="w3-bar-item w3-button">Exams <span class="w3-tag w3-red w3-right w3-margin-right">2</span></a>
<a href="student_data.php" class="w3-bar-item w3-button">Student Management</a>
   <a href="module_data.php" class="w3-bar-item w3-button">Module Management</a>
    <a href="exam_data.php" class="w3-bar-item w3-button">Exam Management</a>
     <a href="exam_submitted.php" class="w3-bar-item w3-button">Result Management</a>


  <a href="#" class="w3-bar-item w3-button">Acknowledgements</a>
    <a href="report.php" class="w3-bar-item w3-button">More reports</a>

  <div class="w3-panel w3-blue-grey w3-display-container">
    <span onclick="this.parentElement.style.display='none'" class="w3-button w3-blue-grey w3-display-topright">&times;</span>
    <p>June/July 2021 MCQ Examinations:</p>
    <?php echo   "Time: " . date("h:i:sa")?> 
  </div>

</div>

<div style="margin-left:20%">


<div class="w3-container">
<body>
    <div class="form">
      <center>


<?php// include 'filesLogic.php';?>

    <div class="container">
      <div class="row">


<?php
include ('dbconnect.php');
require_once("dbcontroller.php");
$db_handle = new DBController();
if(!empty($_POST["submit"])) {
    $query = "INSERT INTO examinfo(module_code, exam_type, exam_date, start_time, completion_time,upload_path) VALUES('".$_POST["module_code"]."','".$_POST["exam_type"]."','".$_POST["exam_date"]."','".$_POST["start_time"]."','".$_POST["end_time"]."','".$_POST["upload_path"]."')";
        $result = $db_handle->executeQuery($query);
    if(!$result){
			$message="Problem in Adding to database. Please Retry.";
	} else {
		
		//header("Location:exam_data.php");
	 echo "<script>alert('Exam was sucessfully added')</script>";
	        header("Location:exam_data.php");
			//require_once ('exam_data.php');
	}



}?>
<!-- <script type="text/javascript">
                alert("Success added.");
                window.location = "exam_data.php";
              </script>

 -->
<link href="style.css" type="text/css" rel="stylesheet" />
<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
<script>
function validate() {
	var valid = true;	
	$(".demoInputBox").css('background-color','');
	$(".info").html('');
	
	if(!$("#module_code").val()) {
		$("#module_code-info").html("(required)");
		$("#module_code").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#myfile").val()) {
		$("#emyfile-info").html("(required)");
		$("#myfile").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#exam_date").val()) {
		$("#exam_date-info").html("(required)");
		$("#exam_date").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#start_time").val()) {
		$("#start_time-info").html("(required)");
		$("#start_time").css('background-color','#FFFFDF');
		valid = false;
	}	
	if(!$("#end_time").val()) {
		$("#end_time-info").html("(required)");
		$("#end_time").css('background-color','#FFFFDF');
		valid = false;
	}	
	return valid;
}
</script>
<h2>Upcoming Examinations </h2>
	<form action="" method="POST" enctype="multipart/form-data">

 <?php
echo '<select class="demoInputBox" name="module_code">
<option>Select Module:</option>';

 $query = "SELECT * FROM module";
$result = mysqli_query($con, $query);
while ($row = mysqli_fetch_array($result)) {
echo '<option>'.$row['module_code'].'</option>';
}

echo '</select>'
 ?>
<br><br>
		<label>Exam type:</label><br>
<br>
<select  name="exam_type" class="demoInputBox"id="exam_type">
<!--   <option value="MCQ">MCQ</option>
  <option value="Fill-in">Fill-in</option> -->
  <option value="file-upload">file-upload</option>
</select>

<br>
<div>
<label style="padding-top:20px;">Number of question:</label>
<span id="name-info" class="info"></span><br/>
<input type="number" name="name" id="name" class="demoInputBox">
</div>
<div>
<label>Exam date</label>
<span id="exam_date-info" class="info"></span><br/>
<input type="date" name="exam_date" id="code" class="demoInputBox"placeholder="yyyy-mm-dd">
</div>
<div>
<label>Start time</label> 
<span id="start_time-info" class="info"></span><br/>
<input type="time" name="start_time" id="category" class="demoInputBox" placeholder="00:00">
</div>
<div>
<label>Complete Time:</label> 
<span id="end_time-info" class="info"></span><br/>
<input type="time" name="end_time" id="price" class="demoInputBox" placeholder="00:00">
</div>
<div>
	<label>Upload Exam File:</label> 

      <input type="file" class="demoInputBox" name="upload_path" accept=".pdf">
 <!--          //<button type="submit" name="submit">upload exam</button> -->
</div>
          <input type="submit" name="submit" id="btnAddAction" value="Add"/>


  </form>
      </div>
    </div>
  </body>
</html>



<!-- 
						
						<div class="form-group">
							<label>Number of question:</label><br>
							<input type="number" class="demoInputBox" name="numOfQuestions" value="1" placeholder="Enter number of questions">
						</div>
						<br>
						<div class="form-group">
							<label>Exam Date:</label><br>
							<input type="date" class="demoInputBox" name="exam_date" value="<?php //echo $exam_date; ?>" placeholder="yyyy-mm-dd">
						</div>
						<br>
						<div class="form-group">
							<label>Start Time:</label><br>
							<input type="time" class="demoInputBox" name="start_time" value="<?php //echo $start_time; ?>" placeholder="00:00">
						</div>
						<div class="form-group">
							<label>Complete Time:</label><br>
							<input type="time" class="demoInputBox" name="end_time" value="<?php //echo $completion_time; ?>" placeholder="00:00">
						</div>
	      <div class="form-group">
          <h3>Upload File</h3>
          <input type="file" name="myfile"> <br>
 <!--          //<button type="submit" name="submit">upload exam</button> -->

          <!-- <input type="submit" name="submit" id="btnAddAction" value="Add" /> --> 

      