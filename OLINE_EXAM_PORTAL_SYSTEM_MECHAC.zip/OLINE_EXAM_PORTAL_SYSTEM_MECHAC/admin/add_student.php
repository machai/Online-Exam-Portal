<?php
//include auth_session.php file on all user panel pages
include("auth_session.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Dashboard - Admin area</title>
    <link rel="stylesheet" href="style.css" />

    <style>


  .rectangle {
  height: 50px;
  width: 270px;
  background-color: #85c1e9;

}
</style>
</head>


<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body>

<div class="w3-sidebar w3-bar-block w3-light-grey" style="width:20%">
  <div class="w3-container w3-dark-grey">
    <h4> Message Of The Day</h4>
  </div>

  <img src="logo.jpg" alt="Snow" style="width:30%">
  <a href="dashboard.php" class="w3-bar-item w3-button w3-red">Admin Home</a>
  <a href="#" class="w3-bar-item w3-button">Exams <span class="w3-tag w3-red w3-right w3-margin-right">2</span></a>
  <a href="student_data.php" class="w3-bar-item w3-button">Student Management</a>
   <a href="module_data.php" class="w3-bar-item w3-button">Module Management</a>
    <a href="exam_data.php" class="w3-bar-item w3-button">Exam Management</a>
     <a href="exam_submitted.php" class="w3-bar-item w3-button">Result Management</a>


  <a href="#" class="w3-bar-item w3-button">Acknowledgements</a>
    <a href="report.php" class="w3-bar-item w3-button">More reports</a>

  <div class="w3-panel w3-blue-grey w3-display-container">
    <span onclick="this.parentElement.style.display='none'" class="w3-button w3-blue-grey w3-display-topright">&times;</span>
    <p>June/July 2021 MCQ Examinations:</p>
    <?php echo   "Time: " . date("h:i:sa")?> 
  </div>

</div>

<div style="margin-left:20%">


<div class="w3-container">
<body>
    <div class="form">
      <center>
</script>
<form action="save_student.php" method="post">
<center><h4><i class="icon-plus-sign icon-large"></i> Add Student</h4></center>
<hr>
<div id="ac">
<label>Student number : </label><br>

<input type="text" style="width:265px; height:30px;" name="student_number" placeholder="Student Number" Required/><br>
<span>student name : </span><br>
<input type="text" style="width:265px; height:30px;" name="student_name" placeholder="Student Name"/><br>
<span>Student Surname : </span><br>
<input type="text" style="width:265px; height:30px;" name="student_surname" placeholder="Student Surname"/><br>

<span>Student Email : </span><br>
<input type="text" style="width:265px; height:30px;" name="student_email" placeholder=" Student Email"/><br><br>


<div style="float:center:10px;">
<button class="btn btn-success " style="width:100px;"></i> Save</button>
</div>
</div>
</form>