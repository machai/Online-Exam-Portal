<?php
//include auth_session.php file on all user panel pages
include("auth_session.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Dashboard - Student area</title>
    <link rel="stylesheet" href="style.css" />

    <style>


  .rectangle {
  height: 50px;
  width: 270px;
  background-color: #85c1e9;

}
</style>
</head>


<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body>

<div class="w3-sidebar w3-bar-block w3-light-grey" style="width:20%">
  <div class="w3-container w3-dark-grey">
    <h4> Message Of The Day</h4>
  </div>

  <img src="logo.jpg" alt="Snow" style="width:30%">
  <a href="dashboard.php" class="w3-bar-item w3-button w3-red">Home</a>
  <a href="exam.php" class="w3-bar-item w3-button">Exams <span class="w3-tag w3-red w3-right w3-margin-right">2</span></a>
  <a href="student_data.php" class="w3-bar-item w3-button">Student Management</a>
  <a href="#" class="w3-bar-item w3-button">Acknowledgements</a>
    <a href="more_report.php" class="w3-bar-item w3-button">More reports</a>

  <div class="w3-panel w3-blue-grey w3-display-container">
    <span onclick="this.parentElement.style.display='none'" class="w3-button w3-blue-grey w3-display-topright">&times;</span>
    <p>June/July 2021 MCQ Examinations:</p>
    <?php echo   "Time: " . date("h:i:sa")?> 
  </div>

</div>

<div style="margin-left:20%">


<div class="w3-container">
<body>
    <div class="form">
      <center>
        <!-- <p>Hello, <?php echo $_SESSION['username']; ?>!</p>
        <img src ="img/graduated.png" alt ="graduate image" style="width: 70px;height: 70px;"> -->
        <p>Welcome to Online Exam - Start Now!</p>
        <p><a href="logout.php">Logout</a></p>

           <!-- reports -->
         <!--   <div class="rectangle">
        <?php //include 'student_report.php'; ?>
      </div>
        <br>
         <div class="rectangle">
          <?php //include 'module_report.php'; ?>
        </div> -->
<div class="segment" style="margin-right:30px;">
		<img src="img/online_exam.png"/>
	</div>
	<div class="segment">
	<h2>Start Test</h2>
	<ul>
		<li><a href="starttest.php">Start Now...</a></li>
	</ul>
	</div>
	
  </div>





      </center>
    </div>

    


</body>
</html>
<?php// include 'inc/footer.php'; ?>