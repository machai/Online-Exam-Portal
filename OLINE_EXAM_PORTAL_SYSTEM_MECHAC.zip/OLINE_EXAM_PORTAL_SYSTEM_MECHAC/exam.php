<!-- <?php
//include auth_session.php file on all user panel pages
//include("auth_session.php");
?> -->


<div style="margin-left:20%">



        <!-- <p>Hello, <?php //echo $_SESSION['username']; ?>!</p>
        <img src ="img/graduated.png" alt ="graduate image" style="width: 70px;height: 70px;">
        <p>Welcome to Online Exam - Start Now!</p>
        <p><a href="logout.php">Logout</a></p>
 -->
          


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
  </head>
<body>
  <nav class="navbar navbar-default">
    <div class="container-fluid">
      <a class="navbar-brand" href='#'>
      <?php 
require_once("slot.php");  
?>
  
</a>
    </div>
  </nav>
  <div class="col-md-3"></div>  
  <div class="col-md-18 well">
    <h3 class="text-primary">Download exam</h3>
    <hr style="border-top:1px dotted #ccc;"/>
    <center>
      <form method="POST" action="upload.php" enctype="multipart/form-data">
        <div class="form-inline">
          <input type="file" class="form-control" name="file" required="required"/>
          <button class="btn btn-primary" name="upload"><span class="glyphicon glyphicon-upload"></span> Submit Exam</button>
        </div>
      </form>
    </center>
    <br />
    <table  border ="1">
      <thead class="alert-info">
        <tr>
          <th>Module Code</th>
          <th>Description</th>
          <th>Exam date</th>
          <th>File</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php
          require 'conn.php';
          $query = $conn->prepare("SELECT * FROM `file`");
          $query->execute();
          while($fetch = $query->fetch()){
        ?>
        <tr>
          <td><?php echo $fetch['ModCode']?></td>
          <td><?php echo $fetch['moduleDescription']?></td>
            <td><?php echo $fetch['DateExam']?></td>
          <td><?php echo $fetch['filename']?></td>
          <td><a href="download.php?file_id=<?php echo $fetch['file_id']?>" class="btn btn-primary">Download Exam</a></td>
        </tr>
        <?php
          }
        ?>
      </tbody>
    </table>
  </div>
</body> 
</html>


      </center>
    </div>

    


</body>
</html>
<?php// include 'inc/footer.php'; ?>